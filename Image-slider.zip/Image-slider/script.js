
jQuery(document).ready(function ($) {

	$(".slider img").first().addClass("first_image active");
	$(".slider img").last().addClass("last_image");

	$('.next-btn').click(function(){

		var active_image = $(document).find('.active');

		$(".slider img").removeClass('active');
		$(active_image).next().addClass('active');

		if( $(active_image).hasClass("last_image") ){
			$('.slider img').first().addClass('active');

		};
	});
	$('.previous-btn').click(function(){

		var active_image = $('.active');

		$(".slider img").removeClass('active');
		$(active_image).prev().addClass('active');

		if ( $(active_image).hasClass("first_image") ) {
			$('.slider img').last().addClass('active');

		}
	});


});            
                   











