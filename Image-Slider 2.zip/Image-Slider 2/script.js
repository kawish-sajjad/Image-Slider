$(document).ready(function(){
	$('img').on('click', function(){
		$('img').removeClass('active');
		$(this).addClass('active');
	});
});